
HSI技術分析報告包
生成時間: 2026-02-08 14:57:16

包含文件:
1. hsi_technical_analysis_report.txt - 詳細技術分析報告
2. hsi_technical_chart.png - 技術分析圖表
3. hsi_realtime.json - 實時數據
4. hsi_history.json - 歷史數據(JSON格式)
5. hsi_history.csv - 歷史數據(CSV格式)

如何使用:
1. 查看報告: 打開 hsi_technical_analysis_report.txt
2. 查看圖表: 打開 hsi_technical_chart.png
3. 分析數據: 使用 hsi_history.csv 進行進一步分析

技術指標包含:
- 移動平均線 (8, 13, 34日)
- RSI指標 (14日)
- 成交量分析
- 斐波那契回撤水平
- 平行通道分析
- 下周走勢預測

數據來源: Futu OpenD
